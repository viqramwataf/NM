import math
# x = 2

def f(x):
    # return x - math.sqrt(x) - math.sin(x)
    return math.exp(x)-(x**2)+(7*x)+3

# print("Let x be 2")
# print(f"f(x) = {f(x)}\n\n")

def g1(x):
    return math.sqrt(x) + math.sin(x)
def g2(x):
    return math.pow(x-math.sin(x),2)
def g3(x):
    return math.asin(x-math.sqrt(x))
def g4(x):
    return ((x**2)-(math.exp(x))-3)/7

# print(f"g1(x) = {g1(x)}")
# print(f"g2(x) = {g2(x)}")
# print(f"g3(x) = {g3(x)}")


def onepointiteration(x) :
    fx = 1
    counter = 0
    
    while (abs(fx)>=0.001):
        print(f"Iterasi ke {counter}")
        nextx = g4(x)
        print(f"x{counter} = {x}, \ng1(x{counter}) = {nextx}, x{counter}+1 = {nextx},")
        fx = f(x)
        x = nextx
        print(f"abs(f(x{counter})) = {abs(fx)}")
        print(f"(f(x{counter})) = {(fx)}")
        print("\n\n")
        counter = counter + 1

onepointiteration(0)



