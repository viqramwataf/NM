from math import log
import math
# xi - (f(xi)/f'(xi))
x = -2

def f(x):
    # return x - sqrt(x) - sin(x)
    return math.exp(x)-(x**2)+(7*x)+3
def fdx(x):
    # return -cos(x) -(1/(2*sqrt(x))) +1
    return math.exp(x)-(2*x)+(7)

# print("Let x be -2")
# print(f"f(x) = {f(x)}\n\n")

# def g1(x):
#     return sqrt(x) + sin(x)
# def g2(x):
#     return pow(x-sin(x),2)
# def g3(x):
#     return asin(x-sqrt(x))

def newtonraphson(x) :
    # fx = 1
    counter = 0
    fx = 1
    while (abs(fx) >= 0.001):
        print(f"Iterasi ke {counter}")
        fx = f(x)
        fdxx = fdx(x)
        print(f"x{counter} = {x}, f(x({counter})) = {f(x)}, fdx(x({counter})) = {fdxx} ,")
        x = x - (f(x)/fdx(x))
        print(f"x{counter}+1 = {x}")
        print("\n\n")
        counter = counter + 1

newtonraphson(0)