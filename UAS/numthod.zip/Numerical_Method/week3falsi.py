import math as m

def epss(n):
    return 0.5 * 10 ** (2 - n)


def function(x):
    # return x ** 3 + 5 * (x ** 2) - 10
    return m.exp(x)-(x**2)+(7*x)+3


def falsi(xl, xu):
    falsicounter(xl, xu, 20)


def xrresult(xl, xu, fxl, fxu):
    return xu-((fxu*(xl-xu)/(fxl-fxu)))


def falsicounter(xl, xu, maxcounter):
    xr = 0
    counter = 1
    espa = 1
    while (espa >= 0.5):
        xrt = xr
        xr = xrresult(xl, xu, function(xl), function(xu))
        print(f'Iterasi ke-{counter}')
        print(f'xr lama= {xrt}, xr baru = {xr}')
        espa = round(abs((xr - xrt) / xr * 100), 6)
        print(f'xl={round(xl,6)}, xu={round(xu,6)}, xr={round(xr,6)}\nf(xl)= {round(function(xl),6)}, f(xu)={round(function(xu),6)}, f(xr)={round(function(xr),6)}, abs(esp a)= {espa}\n\n')
        if (function(xl)*function(xr) > 0):
            xl = xr
        elif (function(xl)*function(xr) < 0):
            xu = xr
        elif (function(xl)*function(xr) == 0):
            print(xr)
        counter += 1

falsi(-5,0)
