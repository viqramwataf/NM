
e = 2.718281828459045

# def epss(n):
#   return 0.5 * 10 ** (2 - n)

# def function(x):
#   return x ** 3 + 5 * (x ** 2) - 10


def function(x):
  return e**x + x


def secant(xl, xb):
    secantcounter(xl, xb)


def xbresult(xl, xb, fxl, fxb):
    return xb-((fxb*(xl-xb)/(fxl-fxb)))


def secantcounter(xl, xb):
    counter = 1
    espa = 1
    while (espa > 0):
        print(f'Iterasi ke-{counter}')
        xlnew = xb
        xb = xbresult(xl, xb, function(xl), function(xb))
        espa = abs((xb - xlnew) / xb * 100)
        print(f'xi-1={round(xl,6)}, xi={round(xlnew,6)}, xi+i={round(xb,6)}\nf(xi-1)= {round(function(xl),6)}, f(xi)={round(function(xlnew),6)}, f(xb)={round(function(xb),6)}, abs(esp a)= {round(espa,6)}\n\n')
        xl = xlnew
        counter += 1
        # if (espa == 0): return

secant(-1, 0)
