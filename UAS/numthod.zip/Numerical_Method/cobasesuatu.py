cf1 = lambda x,y,z: (3*x)+(2*y)
cf2 = lambda x,y,z: (2*x)+(4*y)+z
cf3 = lambda x,y,z: (2*x)+(y)+(4*z)


a = cf1(-0.16667,1.33333,-3.35417)
print(a)
b = cf2(-0.16667,1.33333,-3.35417)
print(b)
c = cf3(-0.16667,1.33333,-3.35417)
print(c)
print("total abs: ", abs(a)+abs(b)+abs(c), "\n\n")


a = cf1(-0.05556,1.60590,-3.37370)
print(a)
b = cf2(-0.05556,1.60590,-3.37370)
print(b)
c = cf3(-0.05556,1.60590,-3.37370)
print(c)
print("total abs: ", abs(a)+abs(b)+abs(c))